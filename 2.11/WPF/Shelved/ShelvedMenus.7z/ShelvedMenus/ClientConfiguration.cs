﻿using System;
 

namespace Model.Entity
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Xml.Linq;

    public class ClientConfiguration
    {
        public static readonly ClientConfiguration Empty = new ClientConfiguration(Enumerable.Empty<Feature>(),
                                                                                   Enumerable.Empty<ROBScreen>(),
                                                                                   Enumerable.Empty<Screen>());
        private readonly HashSet<Feature> _activeFeatures;
        // private readonly List<ROBScreen> _robScreens;
        private readonly List<Screen> _screens;
        private List<Screen> _groupedScreens;        
        private readonly string _startScreen;
        private Dictionary<string, string> _analytics;
        private Dictionary<string, string> _configuration;
        public ClientConfiguration(IEnumerable<Feature> activeFeatures, IEnumerable<ROBScreen> robScreens, IEnumerable<Screen> screens, string startScreen = null, Dictionary<string, string> analytics = null, Dictionary<string, string> configuration = null)
        {
            _activeFeatures = new HashSet<Feature>(activeFeatures);
            // _robScreens = new List<ROBScreen>(robScreens);
            _screens = new List<Screen>(screens);

            //_groupedScreens = GroupScreens(_screens);


            var defualtScreen = _screens.FirstOrDefault(screen => screen.IsDefault);
            if (defualtScreen != null)
                _startScreen = defualtScreen.Uri;

            _analytics = analytics;
            _configuration = configuration;

            //const string fundingAppTypeTitle = "Funding";
            //var fundingScreen = _robScreens.FirstOrDefault(rs => rs.Title == fundingAppTypeTitle);
            //if (fundingScreen != null)
            //    FundingAppTypeId = fundingScreen.AppTypeID;
        }

        //private List<Screen> GroupScreens(List<Screen> screens)
        //{
        //    var groupedScreens = new List<Screen>();

        //    var groupings = screens.GroupBy(s => s.Group);
        //    foreach (var group in groupings)
        //    {
        //        var screen = new Screen
        //        {
        //            Key = group.Key,
        //            Children = group.ToList(),
        //            Label = group.Key
        //        };
        //        groupedScreens.Add(screen);
        //    }

        //    return groupedScreens;
        //}

        public string StartScreen
        {
            get { return _startScreen; }
        }

        public static ClientConfiguration Everything
        {
            get { return new ClientConfiguration(Feature.None(), Enumerable.Empty<ROBScreen>(), Enumerable.Empty<Screen>()); }
        }

        public Dictionary<string, string> Analytics
        {
            get { return _analytics; }

        }

        public Dictionary<string, string> Configuration
        {
            get { return _configuration; }

        }

        public bool IsPromotionsChartingActive
        {
            get
            {
                return _activeFeatures.Contains(Feature.PromotionsCharting);
            }
        }

        public bool IsPromotionDatePeriodsActive
        {
            get { return _activeFeatures.Contains(Feature.PromotionDatePeriods); }
        }

        public bool IsCannibalisationActive
        {
            get { return _activeFeatures.Contains(Feature.Cannibalisation); }
        }

        //Can be removed?
        public bool IsPostPromoActive
        {
            get { return _activeFeatures.Contains(Feature.PostPromo); }
        }

        public bool IsPromotionsSubCustomerActive
        {
            get { return _activeFeatures.Contains(Feature.PromotionsSubCustomer); }
        }

        public bool IsPaymentsSubCustomerActive
        {
            get { return _activeFeatures.Contains(Feature.PaymentsSubCustomer); }
        }

        public bool IsDiagnosticsAccountPlanQueues
        {
            get { return _activeFeatures.Contains(Feature.DiagnosticsAccountPlanQueues); }
        }

        public bool IsDiagnosticsTab
        {
            get { return _activeFeatures.Contains(Feature.DiagnosticsTab); }
        }

        public bool IsPaymentsActive
        {
            get { return _activeFeatures.Contains(Feature.Payments); }
        }

        public bool IsPhasingActive
        {
            get { return _activeFeatures.Contains(Feature.Phasing); }
        }

        public List<Screen> ROBScreens
        {
            get { return Screens.Where(p => p.RobAppType != null).ToList(); }
        }

        public List<Screen> Screens
        {
            get { return _screens; }
        }

        public List<Screen> GroupedScreens
        {
            get { return _groupedScreens; }
        }

        public bool IsPhasingDailyActive
        {
            get { return _activeFeatures.Contains(Feature.PhasingDaily); }
        }

        public bool IsPhasingPostActive
        {
            get { return _activeFeatures.Contains(Feature.PhasingPost); }
        }

        public bool IsDailyVolumePhasingActive
        {
            get { return _activeFeatures.Contains(Feature.DailyVolume); }
        }

        public bool IsWeeklyVolumePhasingActive
        {
            get { return _activeFeatures.Contains(Feature.WeeklyVolume); }
        }

        public bool IsCreateClaimsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateClaims); }
        }


        // target

        public bool IsCreateTargetActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTarget); }
        }

        public bool IsCopyTargetActive
        {
            get { return _activeFeatures.Contains(Feature.CopyTarget); }
        }

        public bool IsDeleteTargetActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteTarget); }
        }

        public bool IsTargetContractsActive
        {
            get { return _activeFeatures.Contains(Feature.TargetContracts); }
        }

        public bool IsCreateTargetContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTargetContracts); }
        }

        public bool IsCopyTargetContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyTargetContracts); }
        }

        public bool IsRemoveTargetContractsActive
        {
            get { return _activeFeatures.Contains(Feature.RemoveTargetContracts); }
        }

        public bool IsSkuDetailTargetActive
        {
            get { return _activeFeatures.Contains(Feature.SkuDetailTarget); }
        }

        public bool IsScheduleTargetActive
        {
            get { return _activeFeatures.Contains(Feature.ScheduleTarget); }
        }

        public static string TargetDefaultTab { get; set; }

        public bool IsGroupCreatorCheckedInTarget
        {
            get { return _activeFeatures.Contains(Feature.TargetDefaultGroupCreator); }
        }

        public bool IsGroupCreatorVisibileInTarget
        {
            get { return _activeFeatures.Contains(Feature.TargetShowGroupCreator); }
        }

        public bool TargetEditorFolderSelector
        {
            get { return _activeFeatures.Contains(Feature.TargetEditorFileSelection); }
        }


        // management adjust

        public bool IsCreateManagementAdjustActive
        {
            get { return _activeFeatures.Contains(Feature.CreateManagementAdjust); }
        }

        public bool IsCopyManagementAdjustActive
        {
            get { return _activeFeatures.Contains(Feature.CopyManagementAdjust); }
        }

        public bool IsDeleteManagementAdjustActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteManagementAdjust); }
        }

        public bool IsManagementAdjustContractsActive
        {
            get { return _activeFeatures.Contains(Feature.ManagementAdjustContracts); }
        }

        public bool IsCreateManagementAdjustContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateManagementAdjustContracts); }
        }

        public bool IsCopyManagementAdjustContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyManagementAdjustContracts); }
        }

        public bool IsRemoveManagementAdjustContractsActive
        {
            get { return _activeFeatures.Contains(Feature.RemoveManagementAdjustContracts); }
        }

        public bool IsSkuDetailManagementAdjustActive
        {
            get { return _activeFeatures.Contains(Feature.SkuDetailManagementAdjust); }
        }

        public bool IsScheduleManagementAdjustActive
        {
            get { return _activeFeatures.Contains(Feature.ScheduleManagementAdjust); }
        }

        public static string ManagementAdjustDefaultTab { get; set; }

        public bool IsGroupCreatorCheckedInManagementAdjust
        {
            get { return _activeFeatures.Contains(Feature.ManagementAdjustDefaultGroupCreator); }
        }

        public bool IsGroupCreatorVisibileInManagementAdjut
        {
            get { return _activeFeatures.Contains(Feature.ManagementAdjustShowGroupCreator); }
        }

        public bool ManagementAdjustEditorFileSelector
        {
            get { return _activeFeatures.Contains(Feature.ManagementAdjustEditorFileSelection); }
        }


        // marketing

        public bool IsCreateMarketingActive
        {
            get { return _activeFeatures.Contains(Feature.CreateMarketing); }
        }

        public bool IsCopyMarketingActive
        {
            get { return _activeFeatures.Contains(Feature.CopyMarketing); }
        }

        public bool IsDeleteMarketingActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteMarketing); }
        }

        public bool IsMarketingContractsActive
        {
            get { return _activeFeatures.Contains(Feature.MarketingContracts); }
        }

        public bool IsCreateMarketingContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateMarketingContracts); }
        }

        public bool IsCopyMarketingContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyMarketingContracts); }
        }

        public bool IsRemoveMarketingContractsActive
        {
            get { return _activeFeatures.Contains(Feature.RemoveMarketingContracts); }
        }

        public bool IsSkuDetailMarketingActive
        {
            get { return _activeFeatures.Contains(Feature.SkuDetailMarketing); }
        }

        public bool IsScheduleMarketingActive
        {
            get { return _activeFeatures.Contains(Feature.ScheduleMarketing); }
        }

        public static string MarketingDefaultTab { get; set; }

        public bool IsGroupCreatorCheckedInMarketing
        {
            get { return _activeFeatures.Contains(Feature.MarketingDefaultGroupCreator); }
        }

        public bool IsGroupCreatorVisibleInMarketing
        {
            get { return _activeFeatures.Contains(Feature.MarketingShowGroupCreator); }
        }

        public bool MarketingEditorFileSelector
        {
            get { return _activeFeatures.Contains(Feature.MarketingEditorFileSelection); }
        }

        public bool IsGroupCreatorVisibileInMarketing
        {
            get { return _activeFeatures.Contains(Feature.MarketingShowGroupCreator); }
        }


        // risk & ops

        public bool IsCreateRiskOpsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateRiskOps); }
        }

        public bool IsCopyRiskOpsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyRiskOps); }
        }

        public bool IsDeleteRiskOpsActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteRiskOps); }
        }

        public bool IsRiskOpsContractsActive
        {
            get { return _activeFeatures.Contains(Feature.RiskOpsContracts); }
        }

        public bool IsCreateRiskOpsContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateRiskOpsContracts); }
        }

        public bool IsCopyRiskOpsContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyRiskOpsContracts); }
        }

        public bool IsRemoveRiskOpsContractsActive
        {
            get { return _activeFeatures.Contains(Feature.RemoveRiskOpsContracts); }
        }

        public bool IsSkuDetailRiskOpsActive
        {
            get { return _activeFeatures.Contains(Feature.SkuDetailRiskOps); }
        }

        public bool IsScheduleRiskOpsActive
        {
            get { return _activeFeatures.Contains(Feature.ScheduleRiskOps); }
        }

        public static string RiskOpsDefaultTab { get; set; }

        public bool IsGroupCreatorCheckedInRiskOps
        {
            get { return _activeFeatures.Contains(Feature.RiskOpsDefaultGroupCreator); }
        }

        public bool IsGroupCreatorVisibleInRiskOps
        {
            get { return _activeFeatures.Contains(Feature.RiskOpsShowGroupCreator); }
        }

        public bool RiskOpsEditorFolderSelector
        {
            get { return _activeFeatures.Contains(Feature.RiskOpsEditorFileSelection); }
        }


        public bool IsCreateTermsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTerms); }
        }

        public bool IsCopyTermsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyTerms); }
        }

        public bool IsDeleteTermsActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteTerms); }
        }

        public bool IsCreateTermContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTermContracts); }
        }

        public bool IsCopyTermContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTermContracts); }
        }

        public bool IsRemoveTermContractsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTermContracts); }
        }

        public bool IsSkuDetailTermsActive
        {
            get { return _activeFeatures.Contains(Feature.SkuDetailTerms); }
        }

        public bool IsScheduleTermsActive
        {
            get { return _activeFeatures.Contains(Feature.ScheduleTerms); }
        }

        public static string TermsDefaultTab { get; set; }

        public bool TermsEditorFolderSelector
        {
            get { return _activeFeatures.Contains(Feature.TermsEditorFileSelection); }
        }

        public bool IsGroupCreatorCheckedInTerms
        {
            get { return _activeFeatures.Contains(Feature.TermsDefaultGroupCreator); }
        }

        public bool IsGroupCreatorVisibleInTerms
        {
            get { return _activeFeatures.Contains(Feature.TermsShowGroupCreator); }
        }

        public bool IsCreatePromotionActive
        {
            get { return _activeFeatures.Contains(Feature.CreatePromotion); }
        }

        public bool IsCopyPromotionActive
        {
            get { return _activeFeatures.Contains(Feature.CopyPromotion); }
        }

        public bool IsDeletePromotionActive
        {
            get { return _activeFeatures.Contains(Feature.DeletePromotion); }
        }

        public bool IsCreatePromotionFromTemplateActive
        {
            get { return _activeFeatures.Contains(Feature.CreatePromotionFromTemplate); }
        }

        public bool IsPromoPowerEditorActive
        {
            get { return _activeFeatures.Contains(Feature.PromoPowerEditor); }
        }

        public bool IsCreateTemplateActive
        {
            get { return _activeFeatures.Contains(Feature.CreateTemplate); }
        }

        public bool IsCopyTemplateActive
        {
            get { return _activeFeatures.Contains(Feature.CopyTemplate); }
        }

        public bool IsDeleteTemplateActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteTemplate); }
        }

        public bool IsCreateNpdActive
        {
            get { return _activeFeatures.Contains(Feature.CreateNpd); }
        }

        public bool IsCopyNpdActive
        {
            get { return _activeFeatures.Contains(Feature.CopyNpd); }
        }

        public bool IsDeleteNpdActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteNpd); }
        }

        public bool IsCreateFundsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateFunds); }
        }

        public bool IsCopyFundsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyFunds); }
        }

        public bool IsDeleteFundsActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteFunds); }
        }

        public bool IsCopyParentFundsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyParentFunds); }
        }

        public bool IsDeleteParentFundsActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteParentFunds); }
        }

        public bool IsTermContractsActive
        {
            get { return _activeFeatures.Contains(Feature.TermContracts); }
        }

        public bool IsSkuDetailFundsActive
        {
            get { return _activeFeatures.Contains(Feature.SkuDetailFunds); }
        }

        public bool IsScheduleFundsActive
        {
            get { return _activeFeatures.Contains(Feature.ScheduleFunds); }
        }

        public static string FundsDefaultTab { get; set; }

        public bool IsFundsTransferActive
        {
            get { return _activeFeatures.Contains(Feature.FundsTransfer); }
        }

        public bool IsCreateScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.CreateScenario); }
        }

        public bool IsCopyScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.CopyScenario); }
        }

        public bool IsDeleteScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteScenario); }
        }

        public bool IsCloseScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.CloseScenario); }
        }

        public bool IsUpdateBudgetScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.UpdateBudgetScenario); }
        }

        public bool IsEditLastClosedScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.EditLastClosedScenario); }
        }

        public bool IsExportScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.ExportScenario); }
        }

        public bool IsPromotionScenarioActive
        {
            get { return _activeFeatures.Contains(Feature.IsPromotionScenarioActive); }
        }

        public bool IsCreateConditionsActive
        {
            get { return _activeFeatures.Contains(Feature.CreateConditions); }
        }

        public bool IsCopyConditionsActive
        {
            get { return _activeFeatures.Contains(Feature.CopyConditions); }
        }

        public bool IsDeleteConditionsActive
        {
            get { return _activeFeatures.Contains(Feature.DeleteConditions); }
        }

        public bool IsCreatePricingActive
        {
            get { return _activeFeatures.Contains(Feature.CreatePricing); }
        }

        public bool IsCommentsActive
        {
            get
            {
                return false; //_activeFeatures.Contains(Feature.Admin); 
            }
        }

        public bool IsJobsActive
        {
            get { return _activeFeatures.Contains(Feature.Jobs); }
        }

        public bool IsSearchKeystroke
        {
            get
            {

                try
                {
                    return _activeFeatures.Contains(Feature.FilterOnKeystroke);
                }
                catch
                {
                    return true;
                }

            }
        }

        public bool IsPromotionProductsRefDataEnabled
        {
            get { return _activeFeatures.Contains(Feature.EnablePromotionProductsReferenceData); }
        }

        public bool IsTemplateRestrainstEnabled
        {
            get { return _activeFeatures.Contains(Feature.EnableTemplateConstraints); }
        }

        public bool IsProductSelectedByDefault
        {
            get { return _activeFeatures.Contains(Feature.ListingsProductSelectedByDefault); }
        }

        public bool IsPromoReviewDetailTabEnabled
        {
            get { return _screens.FirstOrDefault(scr => scr.Key == ScreenKeys.INSIGHTS.ToString()) != null; }
        }

        public bool IsRetainFilterSelectionEnabled
        {
            get { return _activeFeatures.Contains(Feature.RetainFilters); }
        }

        #region Demand Flags

        public bool IsNewFcVisible
        {
            get { return _activeFeatures.Contains(Feature.NewFc); }
        }

        public bool IsCopyFcVisible
        {
            get { return _activeFeatures.Contains(Feature.CopyFc); }
        }

        public bool IsDeleteFcVisible
        {
            get { return _activeFeatures.Contains(Feature.DeleteFc); }
        }

        public bool IsBulkFcVisible
        {
            get { return _activeFeatures.Contains(Feature.BulkFc); }
        }

        #endregion

        public string FundingAppTypeId { get; private set; }

        internal static ClientConfiguration FromXml(XElement clientConfigXml)
        {
            var activeFeatures = GetActiveFeatures(clientConfigXml);
            var startScreen = GetStartScreen(clientConfigXml);
            // var robScreens = GetROBScreens(clientConfigXml);
            var screens = GetScreens(clientConfigXml);

            var xElement = clientConfigXml.Element("SysConfig");
            if (xElement != null)
            {
                User.CurrentUser.DisplayName = xElement.Element("DisplayName").MaybeValue();
                User.CurrentUser.LanguageCode = xElement.Element("LanguageCode").MaybeValue();
                User.CurrentUser.SalesOrganisationID = Convert.ToInt32(xElement.Element("DefaultSalesOrg").MaybeValue());
            }

            Dictionary<string, string> analytics = GetURLs(clientConfigXml, "AnalyticsURL");
            Dictionary<string, string> configuration = GetConfiguation(clientConfigXml, "Configuration");
            return new ClientConfiguration(activeFeatures, null, screens, startScreen, analytics, configuration);
        }

        public static string LanguageCode { get; set; }

        public static string DisplayName { get; set; }

        private static Dictionary<string, string> GetURLs(XElement clientConfigXml, string p)
        {
            var res = clientConfigXml.Elements("SysConfig").Elements("Config").Elements("ConfigItem");

            var q = (from element in res
                     where element.Element("Section").MaybeValue() == "Analytics"
                     select new
                     {
                         Name = element.Element("Key").MaybeValue(),
                         Value = element.Element("Value").MaybeValue()
                     }).ToDictionary(o => o.Name, o => o.Value);

            return q;
        }

        private static Dictionary<string, string> GetConfiguation(XElement clientConfigXml, string p)
        {
            var res = clientConfigXml.Elements("SysConfig").Elements("Config").Elements("ConfigItem");

            var q = (from element in res
                     where element.Element("Section").MaybeValue() == p
                     select new
                     {
                         Name = element.Element("Key").MaybeValue(),
                         Value = element.Element("Value").MaybeValue()
                     }).ToDictionary(o => o.Name, o => o.Value);

            // todo: ### CONSTRAINTS TO REFACTOR
            foreach (var xTab in clientConfigXml.Elements("SysConfig").Elements("Screens").Elements("Screen").Elements("Tabs").Elements("Tab"))
            {
                var xKey = xTab.Element("Key");
                if (xKey != null)
                    switch (xKey.Value)
                    {
                        case "TEMPLATE":
                            if (!q.ContainsKey("IsTemplatingActive"))
                                q.Add("IsTemplatingActive", "1"); break;
                    }
            }
            // /### CONSTRAINTS TO REFACTOR

            return q;
        }

        private static IEnumerable<Feature> GetActiveFeatures(XElement clientConfigXml)
        {

            var res = clientConfigXml.Elements("SysConfig").Elements("Config").Elements("ConfigItem");

            var q = (
                    from element in res
                    where element.Element("Section").MaybeValue() == "ActiveFeatures"
                        && element.Element("Value").MaybeValue() == "1"
                    select element.Element("Key").MaybeValue()
                    ).ToList();

            // todo: ### CONSTRAINTS TO REFACTOR
            //foreach (var xTab in clientConfigXml.Elements("SysConfig").Elements("Screens").Elements("Screen").Elements("Tabs").Elements("Tab"))

            foreach (var xScreen in clientConfigXml.Elements("SysConfig").Elements("Screens").Elements("Screen"))
            {
                XElement xNewButton;
                XElement xCopyButton;
                XElement xDeleteButton;
                XElement xIsGroupCreatorChecked;
                XElement FileSelectorVisibile;
                XElement ShowGroupCreator;

                var xKey = xScreen.Element("Key");
                if (xKey != null)
                    switch (xKey.Value)
                    {
                        case "DIAGNOSTICS":
                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                switch (tab.Element("Key").Value)
                                {
                                    case "XML":
                                        q.Add(Feature.DiagnosticsTab.Name); break;
                                    case "ACCOUNTPLANQUEUES":
                                        q.Add(Feature.DiagnosticsAccountPlanQueues.Name); break;
                                }
                            }
                            break;


                        case "PROMOTION":
                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");
                                switch (tab.Element("Key").Value)
                                {
                                    case "PROMOTION":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreatePromotion.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyPromotion.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeletePromotion.Name);
                                        break;
                                    case "CHART":
                                        q.Add(Feature.PromotionsCharting.Name); break;
                                    case "TEMPLATE":
                                        var xCreateButton = tab.Element("CreatePromotionFromTemplate");
                                        if (xCreateButton.MaybeValue() == "1") q.Add(Feature.CreatePromotionFromTemplate.Name);
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateTemplate.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyTemplate.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteTemplate.Name);
                                        break;
                                }
                            }
                            break;

                        case "NPD":

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");
                                switch (tab.Element("Key").Value)
                                {
                                    case "NPD":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateNpd.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyNpd.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteNpd.Name);
                                        break;
                                }
                            }
                            break;

                        case "FUND":

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");

                                switch (tab.Element("Key").Value)
                                {
                                    case "FUND":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateFunds.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyFunds.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteFunds.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            FundsDefaultTab = "RadTabItem";
                                        break;
                                }
                            }
                            break;

                        case "SCENARIO":

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");
                                var xCloseButton = tab.Element("CloseButton");
                                var xExportButton = tab.Element("ExportButton");
                                var xUpdateBudgetsButton = tab.Element("UpdateBudgetsButton");
                                var xUpdateLatestClosedButton = tab.Element("UpdateLatestClosedButton");
                                switch (tab.Element("Key").Value)
                                {
                                    case "SCENARIO":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateScenario.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyScenario.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteScenario.Name);
                                        if (xCloseButton.MaybeValue() == "1") q.Add(Feature.CloseScenario.Name);
                                        if (xExportButton.MaybeValue() == "1") q.Add(Feature.ExportScenario.Name);
                                        if (xUpdateBudgetsButton.MaybeValue() == "1") q.Add(Feature.UpdateBudgetScenario.Name);
                                        if (xUpdateLatestClosedButton.MaybeValue() == "1") q.Add(Feature.EditLastClosedScenario.Name);
                                        break;
                                }
                            }

                            break;

                        case "PRICING":

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                switch (tab.Element("Key").Value)
                                {
                                    case "PRICING":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreatePricing.Name);
                                        break;
                                }
                            }
                            break;

                        case "CONDITION":

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");
                                switch (tab.Element("Key").Value)
                                {
                                    case "CONDITION":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateConditions.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyConditions.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteConditions.Name);
                                        break;
                                }
                            }

                            break;

                        case "CLAIM":

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                switch (tab.Element("Key").Value)
                                {
                                    case "CLAIM":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateClaims.Name);
                                        break;
                                }
                            }

                            break;

                        case "TERMS":

                            xIsGroupCreatorChecked = xScreen.Element("IsGroupCreatorChecked");
                            if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.TermsDefaultGroupCreator.Name);

                            ShowGroupCreator = xScreen.Element("ShowGroupCreator");
                            if (ShowGroupCreator.MaybeValue() == "1") q.Add(Feature.TermsShowGroupCreator.Name);

                            FileSelectorVisibile = xScreen.MaybeElement("FileSelector");
                            if (FileSelectorVisibile.MaybeValue() == "1") q.Add(Feature.TermsEditorFileSelection.Name);

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");

                                switch (tab.Element("Key").Value)
                                {
                                    case "TERMS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateTerms.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyTerms.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteTerms.Name);
                                        if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.TermsDefaultGroupCreator.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TermsDefaultTab = "RadTabItem";

                                        break;

                                    case "CONTRACTS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateTermContracts.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyTermContracts.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.RemoveTermContracts.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TermsDefaultTab = "ContractsTab";

                                        q.Add(Feature.TermContracts.Name); break;

                                    case "SKU_LIST":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TermsDefaultTab = "SkuDetailTab";

                                        q.Add(Feature.SkuDetailTerms.Name); break;

                                    case "SCHEDULE":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TermsDefaultTab = "ScheduleTab";

                                        q.Add(Feature.ScheduleTerms.Name); break;
                                }
                            }

                            break;

                        case "RISK_OPS":
                            xIsGroupCreatorChecked = xScreen.Element("IsGroupCreatorChecked");
                            if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.RiskOpsDefaultGroupCreator.Name);

                            ShowGroupCreator = xScreen.Element("ShowGroupCreator");
                            if (ShowGroupCreator.MaybeValue() == "1") q.Add(Feature.RiskOpsShowGroupCreator.Name);

                            FileSelectorVisibile = xScreen.MaybeElement("FileSelector");
                            if (FileSelectorVisibile.MaybeValue() == "1") q.Add(Feature.RiskOpsEditorFileSelection.Name);

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");

                                switch (tab.Element("Key").Value)
                                {
                                    case "RISK_OPS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateRiskOps.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyRiskOps.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteRiskOps.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            RiskOpsDefaultTab = "RadTabItem";
                                        break;

                                    case "CONTRACTS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateRiskOpsContracts.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyRiskOpsContracts.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.RemoveRiskOpsContracts.Name);


                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            RiskOpsDefaultTab = "ContractsTab";

                                        q.Add(Feature.RiskOpsContracts.Name); break;

                                    case "SKU_LIST":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            RiskOpsDefaultTab = "SkuDetailTab";

                                        q.Add(Feature.SkuDetailRiskOps.Name); break;

                                    case "SCHEDULE":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            RiskOpsDefaultTab = "ScheduleTab";

                                        q.Add(Feature.ScheduleRiskOps.Name); break;
                                }
                            }

                            break;

                        case "MARKETING":

                            xIsGroupCreatorChecked = xScreen.Element("IsGroupCreatorChecked");
                            if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.MarketingDefaultGroupCreator.Name);

                            ShowGroupCreator = xScreen.Element("ShowGroupCreator");
                            if (ShowGroupCreator.MaybeValue() == "1") q.Add(Feature.MarketingShowGroupCreator.Name);

                            FileSelectorVisibile = xScreen.MaybeElement("FileSelector");
                            if (FileSelectorVisibile.MaybeValue() == "1") q.Add(Feature.MarketingEditorFileSelection.Name);

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");

                                switch (tab.Element("Key").Value)
                                {
                                    case "MARKETING":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateMarketing.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyMarketing.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteMarketing.Name);
                                        if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.MarketingDefaultGroupCreator.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            MarketingDefaultTab = "RadTabItem";

                                        break;

                                    case "CONTRACTS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateMarketingContracts.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyMarketingContracts.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.RemoveMarketingContracts.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            MarketingDefaultTab = "ContractsTab";

                                        q.Add(Feature.MarketingContracts.Name); break;

                                    case "SKU_LIST":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            MarketingDefaultTab = "SkuDetailTab";

                                        q.Add(Feature.SkuDetailMarketing.Name); break;

                                    case "SCHEDULE":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            MarketingDefaultTab = "ScheduleTab";

                                        q.Add(Feature.ScheduleMarketing.Name); break;
                                }
                            }

                            break;

                        case "MANAGEMENTADJUST":

                            xIsGroupCreatorChecked = xScreen.Element("IsGroupCreatorChecked");
                            if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.ManagementAdjustDefaultGroupCreator.Name);

                            ShowGroupCreator = xScreen.Element("ShowGroupCreator");
                            if (ShowGroupCreator.MaybeValue() == "1") q.Add(Feature.ManagementAdjustShowGroupCreator.Name);

                            FileSelectorVisibile = xScreen.MaybeElement("FileSelector");
                            if (FileSelectorVisibile.MaybeValue() == "1") q.Add(Feature.ManagementAdjustEditorFileSelection.Name);

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");

                                switch (tab.Element("Key").Value)
                                {
                                    case "MANAGEMENTADJUST":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateManagementAdjust.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyManagementAdjust.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteManagementAdjust.Name);
                                        if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.ManagementAdjustDefaultGroupCreator.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            ManagementAdjustDefaultTab = "RadTabItem";

                                        break;

                                    case "CONTRACTS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateManagementAdjustContracts.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyManagementAdjustContracts.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.RemoveManagementAdjustContracts.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            ManagementAdjustDefaultTab = "ContractsTab";

                                        q.Add(Feature.ManagementAdjustContracts.Name); break;

                                    case "SKU_LIST":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            ManagementAdjustDefaultTab = "SkuDetailTab";

                                        q.Add(Feature.SkuDetailManagementAdjust.Name); break;

                                    case "SCHEDULE":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            ManagementAdjustDefaultTab = "ScheduleTab";

                                        q.Add(Feature.ScheduleManagementAdjust.Name); break;
                                }
                            }

                            break;

                        case "TARGET":

                            xIsGroupCreatorChecked = xScreen.Element("IsGroupCreatorChecked");
                            if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.TargetDefaultGroupCreator.Name);

                            ShowGroupCreator = xScreen.Element("ShowGroupCreator");
                            if (ShowGroupCreator.MaybeValue() == "1") q.Add(Feature.TargetShowGroupCreator.Name);

                            FileSelectorVisibile = xScreen.MaybeElement("FileSelector");
                            if (FileSelectorVisibile.MaybeValue() == "1") q.Add(Feature.TargetEditorFileSelection.Name);

                            foreach (var tab in xScreen.Elements("Tabs").Elements("Tab"))
                            {
                                xNewButton = tab.Element("NewButton");
                                xCopyButton = tab.Element("CopyButton");
                                xDeleteButton = tab.Element("DeleteButton");

                                switch (tab.Element("Key").Value)
                                {
                                    case "TARGET":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateTarget.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyTarget.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.DeleteTarget.Name);
                                        if (xIsGroupCreatorChecked.MaybeValue() == "1") q.Add(Feature.TargetDefaultGroupCreator.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TargetDefaultTab = "RadTabItem";

                                        break;

                                    case "CONTRACTS":
                                        if (xNewButton.MaybeValue() == "1") q.Add(Feature.CreateTargetContracts.Name);
                                        if (xCopyButton.MaybeValue() == "1") q.Add(Feature.CopyTargetContracts.Name);
                                        if (xDeleteButton.MaybeValue() == "1") q.Add(Feature.RemoveTargetContracts.Name);

                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TargetDefaultTab = "ContractsTab";

                                        q.Add(Feature.TargetContracts.Name); break;

                                    case "SKU_LIST":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TargetDefaultTab = "SkuDetailTab";

                                        q.Add(Feature.SkuDetailTarget.Name); break;

                                    case "SCHEDULE":
                                        if (tab.Element("IsDefault").MaybeValue() == "1")
                                            TargetDefaultTab = "ScheduleTab";

                                        q.Add(Feature.ScheduleTarget.Name); break;
                                }
                            }

                            break;

                    }
            }
            // /### CONSTRAINTS TO REFACTOR

            IEnumerable<Feature> activeFeatures = q.Where(Feature.IsDefined).Select(Feature.Parse);
            return activeFeatures;
        }


        private static IEnumerable<ROBScreen> GetROBScreens(XElement clientConfigXml)
        {

            var res = clientConfigXml.Elements("SysConfig").Elements("Config").Elements("ConfigItem");

            var q = (from element in res
                     where element.Element("Section").MaybeValue() == "ActiveFeatures"
                         && (element.Element("Key").MaybeValue() ?? string.Empty).StartsWith("ROB:")
                     select
                         new ROBScreen
                         {
                             AppTypeID = element.Element("Value").MaybeValue(),
                             Title = element.Element("Key").MaybeValue().Substring(4),
                             Key = element.Element("Key").MaybeValue()
                         }).ToList();

            q.ToList().ForEach(x => x.Create =
                (from element in res
                 where element.Element("Section").MaybeValue() == "ActiveFeatures"
                     && (element.Element("Key").MaybeValue() ?? string.Empty).StartsWith("ROBCreate:" + x.Title)
                 select element.Element("Value").MaybeValue()).FirstOrDefault() == "1" ? true : false);

            q.ToList().ForEach(x => x.Recipient =
                (from element in res
                 where element.Element("Section").MaybeValue() == "ActiveFeatures"
                     && (element.Element("Key").MaybeValue() ?? string.Empty).StartsWith("ROBRecipient:" + x.Title)
                 select element.Element("Value").MaybeValue()).FirstOrDefault() == "1" ? true : false);

            return q;
        }

        private static List<Screen> GetScreens(XElement clientConfigXml)
        {
            List<Screen> screens = new List<Screen>();
            GetScreenFromXml(clientConfigXml, screens);

            return screens;
        }

        private static void GetScreenFromXml(XElement clientConfigXml, List<Screen> screens)
        {
            foreach (var xScreen in XElement.Parse("<Screens><Screen><Key>PLANNING</Key><IsDefault>0</IsDefault><SortOrder>1</SortOrder><Group>Group1</Group></Screen><Screen><Key>INSIGHTS</Key><IsDefault>0</IsDefault><SortOrder>2</SortOrder><Group>Group1</Group><Tabs><Tab><Key>INSIGHTS</Key><Label>INSIGHTS</Label><LabelKey>TAB_INSIGHTS</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>CANVAS</Key><IsDefault>0</IsDefault><SortOrder>3</SortOrder><Group>Group1</Group><Tabs><Tab><Key>CANVAS</Key><Label>CANVAS</Label><LabelKey>TAB_CANVAS</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>ANALYTICS</Key><IsDefault>0</IsDefault><SortOrder>4</SortOrder><Group>Group1</Group><Tabs><Tab><Key>ANALYTICS</Key><Label>ANALYTICS</Label><LabelKey>TAB_ANALYTICS</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>SCHEDULE</Key><IsDefault>0</IsDefault><SortOrder>5</SortOrder><Group>Group99</Group><Tabs><Tab><Key>SCHEDULE</Key><Label>SCHEDULE</Label><LabelKey>TAB_SCHEDULE</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>PRICING</Key><IsDefault>0</IsDefault><SortOrder>6</SortOrder><Group>Group22</Group><Tabs><Tab><Key>PRICING</Key><Label>PRICING</Label><LabelKey>TAB_PRICING</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton></Tab></Tabs></Screen><Screen><Key>PROMOTION</Key><IsDefault>1</IsDefault><SortOrder>7</SortOrder><Group>Group2</Group><Tabs><Tab><Key>CHART</Key><Label>PROMOTION</Label><LabelKey>TAB_CHART</LabelKey><IsDefault>0</IsDefault><CreatePromotionFromTemplate>1</CreatePromotionFromTemplate></Tab><Tab><Key>PROMOTION</Key><Label>PROMOTION</Label><LabelKey>TAB_PROMOTION</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton><CreatePromotionFromTemplate>1</CreatePromotionFromTemplate></Tab><Tab><Key>TEMPLATE</Key><Label>PROMOTION</Label><LabelKey>TAB_TEMPLATE</LabelKey><IsDefault>0</IsDefault><NewButton>1</NewButton><CreateButton>1</CreateButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton><CreatePromotionFromTemplate>1</CreatePromotionFromTemplate></Tab></Tabs></Screen><Screen><Key>FUND</Key><IsDefault>0</IsDefault><SortOrder>8</SortOrder><Group>Group2</Group><Tabs><Tab><Key>FUND</Key><Label>FUND</Label><LabelKey>TAB_FUND</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>TERMS</Key><ROBAppType>300</ROBAppType><ROBRecipient>0</ROBRecipient><IsFilteredByListings>1</IsFilteredByListings><ShowGroupCreator>1</ShowGroupCreator><IsGroupCreatorChecked>1</IsGroupCreatorChecked><FileSelector>1</FileSelector><IsDefault>0</IsDefault><SortOrder>300</SortOrder><Group>Group3</Group><Tabs><Tab><Key>TERMS</Key><Label>Terms</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab><Tab><Key>SKU_LIST</Key><Label>SKUs</Label><IsDefault>1</IsDefault></Tab><Tab><Key>SCHEDULE</Key><Label>Schedule</Label><IsDefault>0</IsDefault></Tab><Tab><Key>CONTRACTS</Key><Label>Contracts</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>RISK_OPS</Key><ROBAppType>400</ROBAppType><ROBRecipient>0</ROBRecipient><IsFilteredByListings>1</IsFilteredByListings><ShowGroupCreator>1</ShowGroupCreator><IsGroupCreatorChecked>0</IsGroupCreatorChecked><FileSelector>1</FileSelector><IsDefault>0</IsDefault><SortOrder>400</SortOrder><Group>Group3</Group><Tabs><Tab><Key>RISK_OPS</Key><Label>Risk &amp; Ops</Label><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab><Tab><Key>SCHEDULE</Key><Label>Schedule</Label><IsDefault>0</IsDefault></Tab><Tab><Key>CONTRACTS</Key><Label>Contracts</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>MARKETING</Key><ROBAppType>500</ROBAppType><ROBRecipient>0</ROBRecipient><IsFilteredByListings>1</IsFilteredByListings><ShowGroupCreator>1</ShowGroupCreator><IsGroupCreatorChecked>0</IsGroupCreatorChecked><FileSelector>1</FileSelector><IsDefault>0</IsDefault><SortOrder>500</SortOrder><Group>Group3</Group><Tabs><Tab><Key>MARKETING</Key><Label>Marketing</Label><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab><Tab><Key>SCHEDULE</Key><Label>Schedule</Label><IsDefault>0</IsDefault></Tab><Tab><Key>CONTRACTS</Key><Label>Contracts</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>MANAGEMENTADJUST</Key><ROBAppType>600</ROBAppType><ROBRecipient>0</ROBRecipient><IsFilteredByListings>1</IsFilteredByListings><ShowGroupCreator>1</ShowGroupCreator><IsGroupCreatorChecked>0</IsGroupCreatorChecked><FileSelector>1</FileSelector><IsDefault>0</IsDefault><SortOrder>600</SortOrder><Group>Group3</Group><Tabs><Tab><Key>MANAGEMENTADJUST</Key><Label>Mgmt Adj</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab><Tab><Key>SCHEDULE</Key><Label>Schedule</Label><IsDefault>1</IsDefault></Tab><Tab><Key>CONTRACTS</Key><Label>Contracts</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>TARGET</Key><ROBAppType>700</ROBAppType><ROBRecipient>0</ROBRecipient><IsFilteredByListings>1</IsFilteredByListings><ShowGroupCreator>1</ShowGroupCreator><IsGroupCreatorChecked>0</IsGroupCreatorChecked><FileSelector>0</FileSelector><IsDefault>0</IsDefault><SortOrder>700</SortOrder><Group>Group3</Group><Tabs><Tab><Key>TARGET</Key><Label>Targets</Label><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab><Tab><Key>SKU_LIST</Key><Label>SKUs</Label><IsDefault>0</IsDefault></Tab><Tab><Key>SCHEDULE</Key><Label>Schedule</Label><IsDefault>0</IsDefault></Tab><Tab><Key>CONTRACTS</Key><Label>Contracts</Label><IsDefault>0</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>SCENARIO</Key><IsDefault>0</IsDefault><SortOrder>1009</SortOrder><Group>Group3</Group><Tabs><Tab><Key>SCENARIO</Key><Label>SCENARIO</Label><LabelKey>TAB_SCENARIO</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton><CloseButton>1</CloseButton><ExportButton>1</ExportButton><UpdateBudgetsButton>1</UpdateBudgetsButton><UpdateLatestClosedButton>1</UpdateLatestClosedButton></Tab></Tabs></Screen><Screen><Key>CONDITION</Key><IsDefault>0</IsDefault><SortOrder>1010</SortOrder><Group>Group3</Group><Tabs><Tab><Key>CONDITION</Key><Label>CONDITION</Label><LabelKey>TAB_CONDITION</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>NPD</Key><IsDefault>0</IsDefault><SortOrder>1011</SortOrder><Group>Group3</Group><Tabs><Tab><Key>NPD</Key><Label>NPD</Label><LabelKey>TAB_NPD</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton><CopyButton>1</CopyButton><DeleteButton>1</DeleteButton></Tab></Tabs></Screen><Screen><Key>CLAIM</Key><IsDefault>0</IsDefault><SortOrder>1012</SortOrder><Group>Group3</Group><Tabs><Tab><Key>CLAIM</Key><Label>CLAIM</Label><LabelKey>TAB_CLAIM</LabelKey><IsDefault>1</IsDefault><NewButton>1</NewButton></Tab></Tabs></Screen><Screen><Key>ADMIN</Key><IsDefault>0</IsDefault><SortOrder>1013</SortOrder><Group>Group3</Group><Tabs><Tab><Key>ADMIN</Key><Label>ADMIN</Label><LabelKey>TAB_ADMIN</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>DPSQL</Key><IsDefault>0</IsDefault><SortOrder>1014</SortOrder><Group>Group4</Group><Tabs><Tab><Key>DPSQL</Key><Label>DPSQL</Label><LabelKey>TAB_DPSQL</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>FCMGMT</Key><IsDefault>0</IsDefault><SortOrder>1015</SortOrder><Group>Group4</Group><Tabs><Tab><Key>FCMGMT</Key><Label>FCMGMT</Label><LabelKey>TAB_FCMGMT</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>SETTINGS</Key><IsDefault>0</IsDefault><SortOrder>1016</SortOrder><Group>Group4</Group><Tabs><Tab><Key>SETTINGS</Key><Label>SETTINGS</Label><LabelKey>TAB_SETTINGS</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen><Screen><Key>DIAGNOSTICS</Key><IsDefault>0</IsDefault><SortOrder>1017</SortOrder><Group>Group5</Group><Tabs><Tab><Key>ACCOUNTPLANQUEUES</Key><Label>DIAGNOSTICS</Label><LabelKey>Account Plan Queues</LabelKey><IsDefault>0</IsDefault></Tab><Tab><Key>XML</Key><Label>DIAGNOSTICS</Label><LabelKey>XML Trace</LabelKey><IsDefault>1</IsDefault></Tab></Tabs></Screen></Screens>").Elements("Screen"))
            {
                var screen = CreateScreenDetail(xScreen);

                //Get the ROB Idx from config not Keys

                if (!string.IsNullOrEmpty(screen.RobAppType))
                {
                    //if (screen.ShowAsROBGroup)
                    //{
                    //    screen.Uri = "/Pages/RobGroups/GroupsList.xaml";
                    //}
                    //else
                    //{
                    screen.Uri = ScreenNavigator.GetUri(screen.Key) + screen.RobAppType;
                    //}
                }
                else
                {
                    screen.Uri = ScreenNavigator.GetUri(screen.Key);
                }



                // todo: ### CONSTRAINTS TO REFACTOR
                if (screen.Key != "DIAGNOSTICS")
                    // /### CONSTRAINTS TO REFACTOR
                    screens.Add(screen);
            }

        }

        private static Screen CreateScreenDetail(XElement xScreen)
        {
            Screen screen = new Screen
            {
                // ReSharper disable PossibleNullReferenceException
                Key = xScreen.Element("Key") != null ? xScreen.Element("Key").Value : null,
                IsDefault = xScreen.Element("IsDefault") != null && xScreen.Element("IsDefault").Value == "1",
                RobAppType = xScreen.Element("ROBAppType").MaybeValue(),
                ShowAsROBGroup = xScreen.Element("ShowAsROBGroup") != null && xScreen.Element("ShowAsROBGroup").Value == "1",
                RobAppRecipient = xScreen.Element("ROBRecipient") != null && xScreen.Element("ROBRecipient").Value == "1",
                IsFilteredByListings = xScreen.Element("IsFilteredByListings") != null && xScreen.Element("IsFilteredByListings").Value == "1",
                Group = xScreen.Element("Group").MaybeValue()
                // Tabs = GetTabs(xScreen.Element("Tabs"))                 
            };
            return screen;
        }

        private static List<Screen> GetTabs(XElement tabs)
        {
            if (tabs != null)
            {
                List<Screen> screens = new List<Screen>();
                foreach (var xScreen in tabs.Elements("Tab"))
                {
                    var screen = CreateScreenDetail(xScreen);
                    ////Get the ROB Idx from config not Keys
                    //screen.Uri = ScreenNavigator.GetUri(screen.Key) + screen.RobAppType;
                    //// todo: ### CONSTRAINTS TO REFACTOR
                    //if (screen.Key != "DIAGNOSTICS")
                    //    // /### CONSTRAINTS TO REFACTOR
                    screens.Add(screen);
                }

                return screens;
            }
            return null;
        }

        private static string GetStartScreen(XElement clientConfigXml)
        {
            var res = clientConfigXml.Elements("SysConfig").Elements("Config").Elements("ConfigItem");

            var q = from element in res
                    where element.Element("Section").MaybeValue() == "StartScreen"
                    select element.Element("Value").MaybeValue();

            return q.FirstOrDefault();
        }

        public bool ScheduleLink
        {
            get
            {
                return _configuration.ContainsKey("ScheduleView_ScheduleLink");

            }
        }

        public bool LockChildren
        {
            get
            {
                string b;
                _configuration.TryGetValue("ROBCreator_LockChildren", out b);

                return b == "1";
            }
        }

        public bool StopPromotionDatePeriodsDropdownReset
        {
            get
            {
                var b = "0";
                _configuration.TryGetValue("StopPromotionDatePeriodsDropdownReset", out b);

                return b == "1";

            }
        }

        public bool CanEnterNegativeClaimsAppotionment
        {
            get
            {
                return _configuration.ContainsKey("Claims_CanEnterNegativeClaimsApportionment");

            }
        }

        public bool ForcePromoProductsExpand
        {
            get
            {
                var a = "0";

                _configuration.TryGetValue("ForcePromoProductsTreeExpand", out a);
                if (a != null)
                    return a == "1";
                else
                    return false;
            }
        }

        public bool IsTemplatingActive
        {
            get
            {
                var a = "0";

                _configuration.TryGetValue("IsTemplatingActive", out a);
                if (a != null)
                    return a == "1";
                else
                    return false;
                //return true;
            }
        }

        public bool UseUpliftForecasting
        {

            get
            {
                var a = "0";

                _configuration.TryGetValue("UseUpliftForecasting", out a);
                if (a != null)
                    return a == "1";
                else
                    return false;
                //return true;
            }

        }

        public string UpliftForecastingURL
        {
            get
            {
                var a = "";

                _configuration.TryGetValue("UpliftForecastingURL", out a);

                return a;
            }
        }

        #region Demand WebService

        public string DemandCalibrateModelUrl
        {
            get
            {
                string a;

                _configuration.TryGetValue("DemandCalibrateModelUrl", out a);

                return a;
            }
        }

        public string DemandCalculateForecastUrl
        {
            get
            {
                string a;

                _configuration.TryGetValue("DemandCalculateForecastUrl", out a);

                return a;
            }
        }

        public string DemandCalculateSeasonalProfileUrl
        {
            get
            {
                string a;

                _configuration.TryGetValue("DemandCalculateSeasonalProfileUrl", out a);

                return a;
            }
        }

        public string DemandSmoothSeasonalProfileUrl
        {
            get
            {
                string a;

                _configuration.TryGetValue("DemandSmoothSeasonalProfileUrl", out a);

                return a;
            }
        }

        public string DemandNormaliseSeasonalProfileUrl
        {
            get
            {
                string a;

                _configuration.TryGetValue("DemandNormaliseSeasonalProfileUrl", out a);

                return a;
            }
        }

        public string DemandNewModelTypesUrl
        {
            get
            {
                string a;

                _configuration.TryGetValue("DemandNewModelTypesUrl", out a);

                return a;
            }
        }


        #endregion

        public bool IsVerBoseLogging
        {
            get
            {
                var a = "0";

                _configuration.TryGetValue("IsVerBoseLogging", out a);
                if (a != null)
                    return a == "1";
                else
                    return false;
                //return true;
            }
        }

        public bool IsPasswordEncrypted
        {
            get
            {
                var a = "0";

                _configuration.TryGetValue("IsPasswordEncrypted", out a);
                if (a != null)
                    return a == "1";
                
                    return false;
            }
        }
    }

    public class ROBScreen
    {
        public string AppTypeID { get; set; }
        public string Title { get; set; }
        public bool Create { get; set; }
        public string Key { get; set; }
        public bool Recipient { get; set; }
    }
}