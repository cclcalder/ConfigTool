﻿using System.Collections.Generic;
using System.ComponentModel;
using Model.Annotations;

namespace Model.Entity
{
     //<Screen>
     //   <Key>TERMS</Key>
     //   <Label>Terms</Label>
     //   <LabelKey>TERMS</LabelKey>
     //   <ROBAppType>300</ROBAppType>
     //   <ROBRecipient>0</ROBRecipient>
     //   <ShowAsROBGroup>1</ShowAsROBGroup>
     //   <IsDefault>0</IsDefault>
     //   <SortOrder>300</SortOrder>
     //   <Tabs>
     //     <Tab>
     //       <Key>TERMS</Key>
     //       <Label>TERMS</Label>
     //       <LabelKey>TAB_TERMS</LabelKey>
     //       <IsDefault>1</IsDefault>
     //       <NewButton>1</NewButton>
     //       <CopyButton>1</CopyButton>
     //       <DeleteButton>1</DeleteButton>
     //     </Tab>
     //     <Tab>
     //       <Key>TERMS</Key>
     //       <Label>Terms</Label>
     //       <IsDefault>1</IsDefault>
     //       <NewButton>1</NewButton>
     //       <CopyButton>1</CopyButton>
     //       <DeleteButton>1</DeleteButton>
     //     </Tab>
     //   </Tabs>
     // </Screen>

    public class Screen : INotifyPropertyChanged
    {
        public string Key { get; set; }

        private string _label;
        public string Label
        {
            get { return _label; }
            set
            {
                _label = value; 
                OnPropertyChanged("Label");
            }
        }

        public bool IsDefault { get; set; }

        public string Uri { get; set; }

        //public string Path
        //{
        //    get
        //    {
        //        if (String.IsNullOrEmpty(RobAppType))
        //        {
        //            return Uri;
        //        }
        //        else
        //        {
        //            //if (ShowAsROBGroup)
        //            //{
        //            //    return Uri + "?ID=" + RobAppType;
        //            //}
        //            //else
        //            //{
        //                return Uri;
        //            //}
        //        }
        //    }
        //}

        public string RobAppType { get; set; }
        public bool RobAppRecipient { get; set; }
        public bool ShowAsROBGroup { get; set; }

        public bool NewButton { get; set; }
        public bool CopyButton { get; set; }
        public bool DeleteButton { get; set; }
        public bool IsFilteredByListings { get; set; }

        public string Group { get; set; }
        public List<Screen> Children { get; set; }

        public List<Screen> Tabs { get; set; }

        public static List<Screen> DEV_ONLY()
        { 
            List<Screen> screens =  new List<Screen>();

           // screens.Add(new Screen() { IsDefault = false, Key = "TermsV2", Label = "TermsV2" , Uri = "/Pages/RobGroups/GroupsList.xaml"});
            screens.Add(new Screen() { IsDefault = false, Key = "Pivot", Label = "Pivot", Uri = "/Pages/canvas/dummy/Pivot1.xaml" });

            return screens;

        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName)); 
        }
    }
}
